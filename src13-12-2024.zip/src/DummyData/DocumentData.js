import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

const DocumentData = [
  {
    icon: <PictureAsPdfIcon/>,
    title: 'Sign document',
    description: 'utility-june-2024.pdf '
  },

 

];

export default DocumentData;