import React from 'react'
import { Box, Typography, Divider, Grid } from '@mui/material';

const RecurringInvoice = () => {
  return (
    <Box>
     No recurring invoices
    </Box>
  )
}
export default RecurringInvoice

