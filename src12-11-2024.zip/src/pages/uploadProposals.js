import React from 'react'


const uploadProposals = () => {

 
  return (
    <div>
      uploadProposals
      uploadProposals
    </div>
  )
}

export default uploadProposals
