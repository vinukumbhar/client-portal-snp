import React from 'react'
import { Box, } from '@mui/material';
const payments = () => {
  return (
    <Box>
     You don't have payments yet.
    </Box>
  )
}

export default payments

