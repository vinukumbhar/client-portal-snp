import React from 'react'

const Archived = () => {
  return (
    <div>
      Archived
      Archived
    </div>
  )
}

export default Archived
