import React from 'react'

const LogIn = () => {
  return (
    <div>
      LogInPage
    
    </div>
  )
}

export default LogIn
