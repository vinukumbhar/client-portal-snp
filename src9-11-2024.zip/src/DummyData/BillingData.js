
import CreditCardIcon from '@mui/icons-material/CreditCard';

const billingCardData = [
  {
    icon: <CreditCardIcon/>,
    title: 'Pay invoice$1.00',
    description: '#2413 '
  },
  
 
];

export default billingCardData;
