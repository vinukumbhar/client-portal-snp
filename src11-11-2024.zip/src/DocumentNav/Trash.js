import React from 'react'

const Trash = () => {
  return (
    <div>
      Trash
      Trash
    </div>
  )
}

export default Trash
